export const environment = {
  production: true,
  server: 'https://localhost:5001/api',
  appKey: '8t4iupbz-aozrohu-vqdu9w6-1iwb8zm',
  storagePrefix: 'AaaS.Chart.'
};
