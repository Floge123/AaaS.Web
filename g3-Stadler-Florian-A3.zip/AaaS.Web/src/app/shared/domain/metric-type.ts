export enum MetricType {
    CountMetric,
    MeasurementMetric,
    IntervalMetric,
    Heartbeat
}