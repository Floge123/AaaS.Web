export class MetricChart {
    constructor(
        public metricName?: string,
        public clientId?: string,
        public chartName?: string,
        public chartType?: string,
        public borderColor?: string,
        public fillColor?: string
    ) {};
}
