export enum ActionType {
  WebHookAction = 'WebHookAction',
  MailAction = 'MailAction'
}
