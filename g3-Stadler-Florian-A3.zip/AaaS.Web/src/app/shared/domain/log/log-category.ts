export enum LogCategory {
  Trace,
  Warning,
  Error
}
