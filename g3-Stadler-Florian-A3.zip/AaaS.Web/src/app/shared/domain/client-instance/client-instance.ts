import {MetricType} from '../metric-type';

export class ClientInstance {
  constructor(
    public appKey: string,
    public clientId: string
  ) {}
}
