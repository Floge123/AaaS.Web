export enum AggregationOperation {
  Sum,
  Average,
  Count
}
