export enum DetectorType {
  MinMaxDetector = 'MinMaxDetector',
  SlidingWindowDetector = 'SlidingWindowDetector'
}
