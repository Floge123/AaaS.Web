export enum ComparisonOperation {
  Less,
  LessOrEqual,
  Equal,
  NotEqual,
  Greater,
  GreaterOrEqual
}
